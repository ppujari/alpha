import time
import edgeiq
import cv2


"""
Sample application using object detection and centroid tracking to count
human faces.
"""


def main():
    try:
        """
        Instantiate alwaysAI Object Detection Class using a face detection
        model and centroid tracker.
        """
        obj_detect = edgeiq.ObjectDetection("alwaysai/MobilenetSSDFace")
        centroid_tracker = edgeiq.CentroidTracker(
                deregister_frames=50, max_distance=50)
        """
        Load Deep Learning Network
        """
        ncs1_on = obj_detect.load(
                engine=edgeiq.Engine.DNN, accelerator=edgeiq.Accelerator.GPU)
        """
        Start your Webcam, Streamer and FPS counter using alwaysAI utilities
        """
        with edgeiq.WebcamVideoStream(cam=0) as video_stream, \
                edgeiq.Streamer() as streamer:
            # Allow Webcam to warm up
            time.sleep(2.0)
            fps = edgeiq.FPS().start()

            # loop detection and centroid tracker
            while True:
                frame = video_stream.read()
                frame = edgeiq.resize(frame, width=400)
                results = obj_detect.detect_objects(frame, confidence_level=.5)

                text = ["Inference time: {:1.3f} s".format(results.duration)]
                text.append("Objects:")

                objects = centroid_tracker.update(results.predictions)

                # Update the label to reflect the object ID
                predictions = []
                for (object_id, prediction) in objects.items():
                    new_label = 'face {}'.format(object_id)
                    prediction.label = new_label
                    text.append(new_label)
                    predictions.append(prediction)

                frame = edgeiq.markup_image(frame, predictions)
                streamer.send_data(frame, text)
                fps.update()

    finally:
        if fps:
            fps.stop()
            print("elapsed time: {:.2f}".format(fps.elapsed()))
            print("approx. FPS: {:.2f}".format(fps.fps()))

        print("Program Ending")
        if ncs1_on:
            obj_detect.ncs1_shutdown()


if __name__ == "__main__":
    main()
