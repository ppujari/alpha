import time
import edgeiq


def main():
    try:
        print("Instantiate alwaysAI Object Detection")
        obj_detect = edgeiq.ObjectDetection("alwaysai/MobileNetSSD")

        print("Load Deep Learning Network")
        ncs1_on = obj_detect.load(engine=edgeiq.Engine.DNN)

        print("Label Information\n{}".format(obj_detect.labels))

        with edgeiq.WebcamVideoStream(cam=0) as video_stream, \
                edgeiq.Streamer() as streamer:
            # Allow Webcam to warm up
            time.sleep(2.0)
            fps = edgeiq.FPS().start()

            # loop detection
            while True:
                frame = video_stream.read()
                results = obj_detect.detect_objects(frame, confidence_level=.5)
                frame = edgeiq.markup_image(
                        frame, results.predictions, colors=obj_detect.colors)

                # Generate text to display on streamer
                text = ["Inference time: {:1.3f} s".format(results.duration)]
                text.append("Objects:")

                for prediction in results.predictions:
                    text.append("{}: {:2.2f}%".format(
                        prediction.label, prediction.confidence * 100))

                streamer.send_data(frame, text)

                fps.update()

    finally:
        if fps:
            fps.stop()
            print("elapsed time: {:.2f}".format(fps.elapsed()))
            print("approx. FPS: {:.2f}".format(fps.fps()))

        print("Program Ending")
        if ncs1_on:
            obj_detect.ncs1_shutdown()


if __name__ == "__main__":
    main()
