import time
import edgeiq


def main():
    try:
        # Instantiate Object Detection Class
        facial_detector = edgeiq.ObjectDetection("alwaysai/MobilenetSSDFace")
        # load an inference engine either DNN (CPU) or Intels NCS1
        # (Movidius Device) by setting engine = "NCS1"
        ncs1_on = facial_detector.load(
                engine=edgeiq.Engine.DNN, accelerator=edgeiq.Accelerator.GPU)

        # start the Webcam
        with edgeiq.WebcamVideoStream(cam=0) as webcam, \
                edgeiq.Streamer() as streamer:
            # warm up webcam
            time.sleep(2.0)
            # start fps counter
            fps = edgeiq.FPS().start()

            # loop detection
            while True:
                frame = webcam.read()
                # detect human faces
                results = facial_detector.detect_objects(
                        frame, confidence_level=.5)
                frame = edgeiq.markup_image(
                        frame, results.predictions, show_labels=False)

                # Generate text to display on streamer
                text = ["Inference time: {:1.3f} s".format(results.duration)]
                text.append("Objects:")

                for prediction in results.predictions:
                    text.append("{:2.2f}%".format(prediction.confidence * 100))

                streamer.send_data(frame, text)

                fps.update()

    finally:
        # stop fps counter and display information
        fps.stop()
        print("[INFO] elapsed time: {:.2f}".format(fps.elapsed()))
        print("[INFO] approx. FPS: {:.2f}".format(fps.fps()))

        if ncs1_on:
            facial_detector.ncs1_shutdown()


if __name__ == "__main__":
    main()
