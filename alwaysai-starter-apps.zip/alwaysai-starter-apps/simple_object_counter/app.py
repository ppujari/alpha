"""
Sample application showing how to create a simple object counter
which could be used part of smart camera security system.
"""

import cv2
import time
import datetime
import edgeiq


###################################################
# Choose objects to count from the following list #
###################################################
"""
background, aeroplane, bicycle, bird, boat,
bottle, bus, car, cat, chair, cow, diningtable,
dog, horse, motorbike, person, pottedplant, sheep,
sofa, train, tvmonitor
"""


OBJECTS = ["person", "chair", "sofa", "pottedplant"]


def main():
    try:
        print("Instantiate alwaysAI Object Detection")
        obj_detect = edgeiq.ObjectDetection("alwaysai/MobileNetSSD")

        print("Load Deep Learning Network")
        ncs1_on = obj_detect.load(engine=edgeiq.Engine.DNN)

        print("Label Information\n{}".format(obj_detect.labels))

        with edgeiq.WebcamVideoStream(cam=0) as video_stream, \
                edgeiq.Streamer() as streamer:
            # Allow Webcam to warm up
            time.sleep(2.0)
            fps = edgeiq.FPS().start()

            # loop detection
            while True:
                frame = video_stream.read()
                results = obj_detect.detect_objects(frame, confidence_level=.5)
                predictions = edgeiq.filter_predictions_by_label(
                        results.predictions, OBJECTS)
                frame = edgeiq.markup_image(
                        frame, predictions, show_confidences=False,
                        colors=obj_detect.colors)

                # Print date and time on frame
                current_time_date = str(datetime.datetime.now())
                (h, w) = frame.shape[:2]
                cv2.putText(
                        frame, current_time_date, (10, h - 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

                # Count objects
                counter = {obj: 0 for obj in OBJECTS}

                for prediction in predictions:
                    # increment the counter of the detected object
                    counter[prediction.label] += 1

                # Generate text to display on streamer
                text = ["Inference time: {:1.3f} s".format(results.duration)]
                text.append("Object counts:")

                for label, count in counter.items():
                    text.append("{}: {}".format(label, count))

                streamer.send_data(frame, text)

                fps.update()

    finally:
        if fps:
            fps.stop()
            print("elapsed time: {:.2f}".format(fps.elapsed()))
            print("approx. FPS: {:.2f}".format(fps.fps()))

        print("Program Ending")
        if ncs1_on:
            obj_detect.ncs1_shutdown()


if __name__ == "__main__":
    main()
