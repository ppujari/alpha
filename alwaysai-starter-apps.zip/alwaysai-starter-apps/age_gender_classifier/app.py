import cv2
import edgeiq


def main():
    try:
        print("Instantiate alwaysAI Multiple Model Classification Object")
        classifier1 = edgeiq.Classification("alwaysai/gendernet")
        classifier2 = edgeiq.Classification("alwaysai/agenet")

        print("Starting VPU")
        ncs1_on1 = classifier1.load(
                edgeiq.Engine.NCS1, edgeiq.Accelerator.NCS1)
        ncs1_on2 = classifier2.load(
                edgeiq.Engine.NCS1, edgeiq.Accelerator.NCS1)

        print("Grabbing Path to Input Images")
        image_paths = sorted(list(edgeiq.list_images("images/")))

        with edgeiq.Streamer(
                queue_depth=len(image_paths), inter_msg_time=3) as streamer:
            for image_path in image_paths:
                image_display = cv2.imread(image_path)
                image = image_display.copy()

                results1 = classifier1.classify_image(image, confidence_level=.95)
                results2 = classifier2.classify_image(image)

                # Generate text to display on streamer
                text = ["Inference time: {:1.3f} s".format(
                    results1.duration + results2.duration)]

                # Find the index of highest confidence
                if len(results1.predictions) > 0:
                    top_prediction1 = results1.predictions[0]
                    top_prediction2 = results2.predictions[0]
                    text1 = "Classification: {}, {:.2f}%".format(
                            top_prediction1.label,
                            top_prediction1.confidence * 100)
                    text2 = "Classification: {}, {:.2f}%".format(
                            top_prediction2.label,
                            top_prediction2.confidence * 100)
                else:
                    text1 = "Can not classify this image, confidence under " \
                            "95 percent for Gender Identification"
                    text2 = None
                # Show the image on which inference was performed with text
                cv2.putText(
                        image_display, text1, (5, 25),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 255), 2)
                text.append(text1)
                if text2 is not None:
                    cv2.putText(
                            image_display, text2, (5, 45),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 255), 2)
                    text.append(text2)

                streamer.send_data(image_display, text)
            streamer.wait()

    finally:
        print("Program Ending")

        if ncs1_on1:
            classifier1.ncs1_shutdown()
        if ncs1_on2:
            classifier2.ncs1_shutdown()


if __name__ == "__main__":
    main()
