import time
import edgeiq
import numpy as np


"""
Sample application that use object detection and tracking to follow
objects.  Detectors are resource expensive so this combination
reduces stress on the system.  Detector is set to execute every 30 frames,
but this can be adjusted by changing the value of detect_period variable
"""


def main():
    try:
        # The current frame index
        frame_idx = 0
        # number of frames to skip before running detector
        detect_period = 30
        """
        Instantiate alwaysAI Object Detection and Correlation Tracker Classes
        """
        obj_detect = edgeiq.ObjectDetection(
                "alwaysai/ssd_mobilenet_v1_coco_2018_01_28")
        tracker = edgeiq.CorrelationTracker()
        """
        Load Deep Learning Network
        """
        ncs1_on = obj_detect.load(
            engine=edgeiq.Engine.DNN, accelerator=edgeiq.Accelerator.GPU)
        """
        Start your Webcam, Streamer and FPS counter using alwaysAI utilities
        """
        with edgeiq.WebcamVideoStream(cam=0) as video_stream, \
                edgeiq.Streamer() as streamer:
            # Allow Webcam to warm up
            time.sleep(2.0)
            fps = edgeiq.FPS().start()
            # loop detection and centroid tracker
            text = []
            while True:
                frame = video_stream.read()
                predictions = []
                if frame_idx % detect_period == 0:
                    results = obj_detect.detect_objects(
                            frame, confidence_level=.5)
                    # Generate text to display on streamer
                    text = [
                            "Inference time: {:1.3f} s".format(
                                results.duration)]
                    text.append("Objects:")

                    # Stop tracking old objects
                    if tracker.count:
                        tracker.stop_all()

                    predictions = results.predictions
                    for prediction in predictions:
                        text.append("{}: {:2.2f}%".format(
                            prediction.label, prediction.confidence * 100))
                        tracker.start(frame, prediction)
                else:
                    if tracker.count:
                        predictions = tracker.update(frame)

                frame = edgeiq.markup_image(
                        frame, predictions, show_labels=True,
                        show_confidences=False, colors=obj_detect.colors)
                streamer.send_data(frame, text)
                frame_idx += 1
                fps.update()

    finally:
        tracker.stop_all()
        if fps:
            fps.stop()
            print("elapsed time: {:.2f}".format(fps.elapsed()))
            print("approx. FPS: {:.2f}".format(fps.fps()))

        print("Program Ending")
        if ncs1_on:
            obj_detect.ncs1_shutdown()


if __name__ == "__main__":
    main()
