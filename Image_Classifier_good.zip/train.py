import torch
import torchvision
from torch import nn, optim
import torch.nn.functional as F
from torchvision import datasets, transforms, models
from collections import OrderedDict
import PIL
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sb
import json
import argparse
import functions

parser = argparse.ArgumentParser(description="Training programmer for image classifier")
parser.add_argument('data_dir', type=str, action='store')
parser.add_argument('--save_dir', dest='save_dir', action='store', default='checkpoint.pth')
parser.add_argument('--arch', dest='architecture', type=str, action='store', default='vgg16')
parser.add_argument('--hidden_units', dest='hidden_units', type=int, action='store', default='4096')
parser.add_argument('--learning_rate', dest='learning_rate', type=float, action='store', default='0.001')
parser.add_argument('--gpu', dest='device', type=str, action='store', required=True)
parser.add_argument('--epochs', dest='epochs', type=int, action='store', default=3)

args = parser.parse_args()

def main():
    data_dir = args.data_dir
    save_dir = args.save_dir
    architecture = args.architecture
    hidden_units = args.hidden_units
    learning_rate = args.learning_rate
    epochs = args.epochs
    device = args.device
    
    print('test')
    
    if device == 'gpu':
        device = 'cuda'
        print('you have chosen gpu, smart move!')
    elif device == 'cpu':
        print('CPU? why you are so dumb!')
    else:
        print('what medicines have you taken?')

    #load data
    trainloader, validloader, testloader, train_datasets = functions.data_loader(data_dir)
    
    #set up the neural network
    model, criterion, optimizer = functions.setup(architecture, hidden_units, learning_rate, device)
    
    #training the model
    model = functions.trainer(model, criterion, optimizer, trainloader, validloader, device, epochs)
    
    #testing the model
    functions.calc_accuracy(model, criterion, testloader, device)

    #save path
    functions.save_model(save_dir, model, architecture, learning_rate, optimizer, epochs, hidden_units)

    print('Training is done. Train model is saved as {}.'.format(save_dir))



if __name__ == "__main__":
    main()
