import torch
import torchvision
from torch import nn, optim
import torch.nn.functional as F
from torchvision import datasets, transforms, models
from collections import OrderedDict
import PIL
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sb
import json
import argparse
import functions

parser = argparse.ArgumentParser(description="This is a program for predicting a flower's class")

parser.add_argument('image_path', type=str, action='store')
parser.add_argument('checkpoint', type=str, action='store')
parser.add_argument('--gpu', dest='device', type=str, action='store', default='gpu')
parser.add_argument('--catergory_names', dest='name_map', type=str, action='store', required=True, default='cat_to_name.json')
parser.add_argument('--topk', dest='k', type=int, action='store', default=5)

args = parser.parse_args()

def main():
 
    image_path = args.image_path
    checkpoint = args.checkpoint
    device = args.device
    name_map = args.name_map
    k = args.k


    if device == 'gpu':
        device = 'cuda'
        print('you have chosen gpu, smart move!')
    elif device == 'cpu':
        print('CPU? why you are so dumb!')
    else:
        print('what medicines have you taken?')

    #load catergory name files
    with open(name_map, 'r') as f:
        name_map = json.load(f)

    #load the model
    model = functions.load_model(checkpoint, device)
    print("model is loaded! Now let's check if this model is working.")

    #testing if the model works
    #_,_,testloader,_ = functions.data_loader()
    #functions.calc_accuracy(model, criterion, testloader, test_epochs=1)

    #predict
    top_probabilities, top_flowers = functions.predict(image_path, model, k, device, name_map)
    for prob, flower in zip(top_probabilities, top_flowers):
        print('Our model predicts there is a {:.4f} chance for this image to be {}'.format(prob, flower))


if __name__ == "__main__":
    main()