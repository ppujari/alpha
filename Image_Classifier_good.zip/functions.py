import torch
import torchvision
from torch import nn, optim
import torch.nn.functional as F
from torchvision import datasets, transforms, models
from collections import OrderedDict
import PIL
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sb
import json
import argparse

# image data loading function
def data_loader(data_dir='flowers'):
    data_dir = data_dir
    train_dir = data_dir + '/train'
    valid_dir = data_dir + '/valid'
    test_dir = data_dir + '/test'
    # TODO: Define your transforms for the training, validation, and testing sets
    train_transforms = transforms.Compose([transforms.RandomRotation(30),
                                           transforms.RandomResizedCrop(224),
                                           transforms.RandomHorizontalFlip(),
                                           transforms.ToTensor(),
                                           transforms.Normalize([0.485, 0.456, 0.406],
                                                               [0.229, 0.224, 0.225])
                                         ])

    valid_transforms = transforms.Compose([transforms.Resize(255),
                                          transforms.RandomCrop(224),
                                          transforms.ToTensor(),
                                          transforms.Normalize([0.485, 0.456, 0.406],
                                                               [0.229, 0.224, 0.225])
                                         ])

    test_transforms = transforms.Compose([transforms.Resize(255),
                                          transforms.RandomCrop(224),
                                          transforms.ToTensor(),
                                          transforms.Normalize([0.485, 0.456, 0.406],
                                                               [0.229, 0.224, 0.225])
                                         ])

    # TODO: Load the datasets with ImageFolder
    train_datasets = datasets.ImageFolder(train_dir, transform=train_transforms)
    valid_datasets = datasets.ImageFolder(valid_dir, transform=valid_transforms)
    test_datasets = datasets.ImageFolder(test_dir, transform=test_transforms)

    # TODO: Using the image datasets and the trainforms, define the dataloaders
    trainloader = torch.utils.data.DataLoader(
        train_datasets, batch_size=50, shuffle=True)
    validloader = torch.utils.data.DataLoader(valid_datasets, batch_size=50)
    testloader = torch.utils.data.DataLoader(
        train_datasets, batch_size=200, shuffle=True)
    
    print ('data loading accomplished!')

    return trainloader, validloader, testloader, train_datasets


# setting up the neural network function

def setup(architecture='vgg16', hidden_units=4096, learning_rate=0.001, device='cuda'):

    if architecture == 'vgg16':
        model = models.vgg16(pretrained=True)
        input_units = model.classifier[0].in_features
        print('vgg16 is chosen')
    elif architecture == 'densenet121':
        model = models.densenet121(pretrained=True)
        input_units = model.classifier[0].in_features
        print('densenet 121 is chosen.')
    else:
        print('this is a dumb program, only vgg16 and densenet121 are available')

    # freeze parameters
    for param in model.parameters():
        param.requires_grad = False

        # define my own classifer
        classifier = nn.Sequential(OrderedDict([
            ('0', nn.Linear(input_units, hidden_units)),
            ('1', nn.ReLU()),
            ('2', nn.Dropout(p=0.5)),
            ('3', nn.Linear(hidden_units, 1000)),
            ('4', nn.ReLU()),
            ('5', nn.Dropout(p=0.5)),
            ('6', nn.Linear(1000, 102)),
            ('output', nn.LogSoftmax(dim=1))
        ]))

        model.classifier = classifier

    criterion = nn.NLLLoss()
    optimizer = optim.Adam(model.classifier.parameters(), lr=learning_rate)

    model.to(device)
    
    print('network setup is accomplished!')

    return model, criterion, optimizer


def validation(model, criterion, dataloader, device):
    
    running_loss = 0
    accuracy = 0
    
    model.to(device)

    for images, labels in iter(dataloader):
        
        images, labels = images.to(device), labels.to(device)
        
        output = model.forward(images)
        loss = criterion(output, labels)
        
        #probability = np.exp(output).to('cuda') 
        equality = (labels.data.to(device) == output.max(dim=1)[1]) #if prediction matches reallity
        accuracy += equality.type(torch.FloatTensor).mean() #calculate accuracy
        
        running_loss += loss.item()
    
    accuracy = accuracy/len(dataloader)
    running_loss = running_loss/len(dataloader)
    
    return accuracy, running_loss


def trainer(model, criterion, optimizer, trainloader, validloader, device, epochs):

    print('Training Starts! Device chosen is {}'.format(device))

    steps = 0
    print_every = 50

    for e in range(epochs):

        model.train()

        running_loss = 0 #set loss to 0 for each epoch

        for images, labels in iter(trainloader):

            images = images.to(device)
            labels = labels.to(device)

            optimizer.zero_grad() #set gradient to zero for each pass

            output = model.forward(images) #feedforward
            loss = criterion(output, labels) #calculate loss
            loss.backward() #backpropagation
            optimizer.step() #gradient descent

            running_loss += loss.item()

            steps += 1

            if steps%print_every == 0:

                model.eval()

                with torch.no_grad():
                    accuracy, validation_loss = validation(model, criterion, validloader, device)

                print("Training steps:{}..".format(steps),
                "Epoch: {}/{}.. ".format(e+1, epochs),
                "Training Loss: {:.4f}.. ".format(running_loss/print_every),
                "Test Loss: {:.4f}.. ".format(validation_loss),
                "Test Accuracy: {:.4f}".format(accuracy))

                running_loss = 0

                model.train()
    
    print('Training is completed!')

    return model



def calc_accuracy(model, criterion, testloader, device, test_epochs=2):

    print('Testing phase starts with {} test epochs'.format(test_epochs))

    model.eval()
    
    for e in range(test_epochs):
        with torch.no_grad():
            accuracy, test_loss = validation(model, criterion, testloader, device)
        print('For test epoch {}, the average accuracy is: {}'.format(e+1, accuracy))


def save_model(save_dir, model, train_datasets, architecture, learning_rate, optimizer, epochs, hidden_units):

    model.class_to_idx = train_datasets.class_to_idx

    checkpoint = {'state_dict': model.state_dict(), 
                'class_to_idx': model.class_to_idx,
                'arch': architecture,
                'learning_rate': learning_rate, 
                'optimizer': optimizer.state_dict(),
                'epoch': epochs,
                'hidden_units': hidden_units}

    torch.save(checkpoint, save_dir)


def load_model(checkpoint_path, device):
    
    checkpoint = torch.load(checkpoint_path)

    architecture = checkpoint['arch']
    hidden_units = checkpoint['hidden_units']
    learning_rate = checkpoint['learning_rate']

    model,_,_ = setup(architecture, hidden_units, learning_rate, device)

    model.class_to_idx = checkpoint['class_to_idx']
    model.load_state_dict(checkpoint['state_dict'])

    return model


def process_image(image):
    ''' Scales, crops, and normalizes a PIL image for a PyTorch model,
        returns an Numpy array
    '''
    img = Image.open(image)
    
    # Resizing the email with thumbnail
    if img.size[0] > img.size[1]: #if width is bigger than height
        img.thumbnail((5000, 256))
    else:
        img.thumbnail((256, 5000))
        
    # Cropping the image
    left_margin = (img.width-224)/2
    right_margin = left_margin + 224
    top_margin = (img.height-224)/2
    bottom_margin = top_margin + 224
    img = img.crop((left_margin, top_margin,
                    right_margin, bottom_margin))
    
    # Normalizing the image
    img = np.array(img)/255 #convert color values to 0-1
    mean = np.array([0.485, 0.456, 0.406]) #create mean array
    std = np.array([0.229, 0.224, 0.225]) #create standard deviation array
    img = (img - mean)/std #normalize
    
    # Move color channel from third dimension to first
    img = img.transpose((2, 0, 1)) 
    
    return img


def predict(image_path, model, topk, device, name_map):
    ''' Predict the class (or classes) of an image using a trained deep learning model.
    '''
    
    # TODO: Implement the code to predict the class from an image file
    
    #process the image to right size and normalize
    im = process_image(image_path)
    
    #convert image to cuda.FloatTensor object
    if device == 'cuda':
        im = torch.from_numpy(im).type(torch.cuda.FloatTensor)
    else:
        im = torch.from_numpy(im).type(torch.FloatTensor)
    
    #add batch_size dimension 
    im.unsqueeze_(0)
    
    #predict with model, take exponential of logSoftmax
    probability = torch.exp(model.forward(im))
    
    #check top 5 probabilities and their respective indexes
    top_probabilities, top_idx = probability.topk(topk)
    top_probabilities = top_probabilities.cpu().detach().numpy().tolist()[0]
    
    #switch key and val of model.class_to_idx
    idx_to_class = {val:key for (key, val) in model.class_to_idx.items()}
    
    #top labels 
    top_labels = [idx_to_class[label] for label in top_idx.cpu().numpy().tolist()[0]]
    
    #top flower names
    top_flowers = [name_map[label] for label in top_labels]

    return top_probabilities, top_flowers
