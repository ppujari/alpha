import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import collections
import random
import numpy as np
import matplotlib.pyplot as plt


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
GAMMA = 0.999
TAU = 0.001
UPDATE_EVERY = 4
# Transition = collections.namedtuple('Transition',
#                         ('state', 'action', 'next_state', 'reward'))

class ReplayMemory(object):
    def __init__(self, capacity):
        self.capacity = capacity
        self.experience = collections.namedtuple('Transition',
                                field_names=['state', 'action', 'reward', 'next_state',  'done'])
        self.memory = collections.deque(maxlen=self.capacity)
        #self.position = 0

    def push(self, *args):
        # if len(self.memory) < self.capacity:
        #     self.memory.append(None)
        # self.memory[self.position] = Transition(*args)
        # self.postion = (self.position + 1) % self.capacity
        self.memory.append(self.experience(*args))
        
    def sample(self, BATCH_SIZE):
        experiences =  random.sample(self.memory, BATCH_SIZE)
        states = torch.from_numpy(np.vstack([e.state for e in experiences if e is not None])).float().to(device)
        actions = torch.from_numpy(np.vstack([e.action for e in experiences if e is not None])).long().to(device)
        rewards = torch.from_numpy(np.vstack([e.reward for e in experiences if e is not None])).float().to(device)
        next_states = torch.from_numpy(np.vstack([e.next_state for e in experiences if e is not None])).float().to(
            device)
        dones = torch.from_numpy(np.vstack([e.done for e in experiences if e is not None]).astype(np.uint8)).float().to(
            device)

        return (states, actions, rewards, next_states, dones)

    def __len__(self):
        return len(self.memory)


class DQN(nn.Module):
    def __init__(self, state_size, hidden_size, action_size):
        super(DQN, self).__init__()
        self.fc1 = nn.Linear(state_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, hidden_size)
        #self.fc3 = nn.Linear(hidden_size, hidden_size)
        self.act = nn.Linear(hidden_size, action_size)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        #x = F.relu(self.fc3(x))
        x = self.act(x)
        return x

# class DQN_2(nn.Module):
#     def __init__(self, state_size, hidden_size_1, action_size):
#         super(DQN, self).__init__()
#         self.fc1 = nn.Linear(state_size, hidden_size_1)
#         self.fc2 = nn.Linear(hidden_size_1, action_size)
#
#     def forward(self, x):
#         x = F.relu(self.fc1(x))
#         x = self.fc2(x)
#
#         return x

class Agent(object):
    def __init__(self, state_size, hidden_size, action_size, device, memory_capacity=10000,
                 EPS_start=0.9, EPS_end=0.05, EPS_decay=200):
        self.t = 0
        self.state_size = state_size
        self.action_size = action_size
        self.device = device
        self.memory_capacity = memory_capacity
        self.init_model(state_size, hidden_size, action_size)
        self.init_memory()

        self.eps = 0
        self.eps_start = EPS_start
        self.eps_end = EPS_end
        self.eps_decay = EPS_decay


    def init_model(self, state_size, hidden_size, action_size):
        self.policy_net = DQN(state_size, hidden_size, action_size).to(self.device)
        self.target_net = DQN(state_size, hidden_size, action_size).to(self.device)
        self.optimizer = optim.Adam(self.policy_net.parameters(),lr=0.001)
        self.target_net.load_state_dict(self.policy_net.state_dict())
        self.target_net.eval()

    def init_memory(self):
        self.memory = ReplayMemory(self.memory_capacity)

    def select_action(self, state, EPS_mode=True):
        if EPS_mode == True:
            if np.random.random() > self.eps:
                with torch.no_grad():
                    action = self.policy_net(torch.from_numpy(state).float().to(device)).max(0)[1].view(1,1)
                    return action.item()

            else:
                action = random.choice(np.arange(self.action_size))
                return action
        else:
            with torch.no_grad():
                action = self.policy_net(torch.from_numpy(state).float().to(device)).max(0)[1].view(1, 1)
                return action.item()

    def learn(self, experiences, GAMMA, TAU, UPDATE_EVERY, DOUBLE = False):
        """
            experiences (Tuple[torch.Tensor]): tuple of (s, a, r, s', done) tuples
        """
        states, actions, rewards, next_states, dones = experiences

        state_action_values = self.policy_net(states).gather(1, actions)

        with torch.no_grad():
            if DOUBLE == False:
                next_state_values = self.target_net(next_states).max(1)[0].unsqueeze(1)
            else:
                next_actions = self.policy_net(next_states).max(1)[1].view(-1, 1)
                next_state_values = self.target_net(next_states).gather(1, next_actions)

        target_state_action_values = (next_state_values * GAMMA) * (1 - dones)+ rewards

        loss = F.mse_loss(state_action_values, target_state_action_values)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        if (self.t + 1) % (UPDATE_EVERY*5) == 0:
            self.soft_update(self.policy_net, self.target_net, TAU)

    def soft_update(self, model_1, model_2, TAU):
        state_1 = model_1.state_dict()
        state_2 = model_2.state_dict()
        temp_state = {item: TAU*state_1[item] + (1-TAU)*state_2[item] for item in state_2}
        model_2.load_state_dict(temp_state)

    def step(self, state, action, reward, next_state, done, GAMMA, TAU, UPDATE_EVERY, BATCH_SIZE=32, DOUBLE=False):
        self.memory.push(state, action, reward, next_state, done)

        if len(self.memory) >= BATCH_SIZE:
            self.t += 1
            if (self.t + 1) % UPDATE_EVERY == 0:
                self.update_eps()
                experiences = self.memory.sample(BATCH_SIZE)
                self.learn(experiences, GAMMA, TAU, UPDATE_EVERY, DOUBLE)

    def update_eps(self,):
        self.eps = self.eps_end + (self.eps_start - self.eps_end) *\
                   np.exp(-1.*self.t/self.eps_decay)


#env = UnityEnvironment(file_name="/data/Banana_Linux_NoVis/Banana.x86_64")
#agent = Agent(37, 30, 30, 4, device)

class GAME(object):
    def __init__(self, env, agent, ):
        self.env = env
        self.brain_name = 'BananaBrain'
        self.agent = agent

        self.train_scores = []
        self.explore_scores = []
        self.best_avg_score = 0

    def train(self, num_episodes, UPDATE_EVERY, GAMMA, TAU, max_step=1000, BATCH_SIZE=32, AVG_WINDOW=10, DOUBLE= False):
        avg_score = 0.
        for episode in range(num_episodes):
            env_info = self.env.reset(train_mode=True)[self.brain_name]
            state = env_info.vector_observations[0]
            score = 0
            step = 0
            while True:
                action = self.agent.select_action(state, True)
                env_info = self.env.step(action)[self.brain_name]
                next_state, reward, done = self.extract_from_info(env_info)
                score += reward
                step += 1
                if done or step > max_step:
                    self.train_scores.append(score)

                    if len(self.train_scores) >= AVG_WINDOW:
                        avg_score = np.mean(self.train_scores[-AVG_WINDOW:])
                        print('Epoch:{}, the score is {}, the total step is {}, average score is {}'.format(episode + 1, score,
                                                                                       step * (episode + 1), avg_score))

                        if avg_score > 13.0 and avg_score > self.best_avg_score:
                            self.best_avg_score = avg_score
                            save_dict = {'policy_net_dict': self.agent.policy_net.state_dict(), 'episode': episode}
                            print('Save model with average score {} at episode {}'.format(avg_score, episode + 1))
                            torch.save(save_dict, './save_model/save_model.pth')
                    else:
                        print('Epoch:{}, the score is {}, the total step is {}'.format(episode + 1, score,
                                                                                       step * (episode + 1)))
                    break
                else:
                    self.agent.step(state, action, reward, next_state, done, GAMMA=GAMMA, TAU=TAU, UPDATE_EVERY=UPDATE_EVERY, BATCH_SIZE=BATCH_SIZE, DOUBLE=DOUBLE)
                    state = next_state

    def explore(self, num_episodes, max_step=1000):
        for episode in range(num_episodes):
            env_info = self.env.reset(train_mode=True)[self.brain_name]
            state = env_info.vector_observations[0]
            score = 0
            step = 0
            while True:
                action = self.agent.select_action(state, False)
                env_info = self.env.step(action)[self.brain_name]
                next_state, reward, done = self.extract_from_info(env_info)
                score += reward
                step += 1
                if done or step > max_step :
                    self.explore_scores.append(score)
                    print('Epoch:{}, the score is {}, the end step is {}'.format(episode + 1, score, step))
                    break
                else:
                    state = next_state

    def extract_from_info(self, env_info):
        next_state = env_info.vector_observations[0]
        reward = env_info.rewards[0]
        done = env_info.local_done[0]
        return next_state, reward, done

    @staticmethod
    def build_average(scores, win_length):
        win_average = []
        for i in range(len(scores) - win_length + 1):
            window = np.mean(scores[i:i + win_length])
            win_average.append(window)
        return win_average

    def training_plot(self):
        AVG_WINDOW = 5
        win_average = self.build_average(self.train_scores, AVG_WINDOW)
        plt.figure(figsize=(15, 10))
        plt.plot(np.arange(AVG_WINDOW - 1, len(self.train_scores)), win_average, linewidth=4)
        plt.plot(np.arange(len(self.train_scores)), self.train_scores, linewidth=2)
        plt.plot(np.arange(len(self.train_scores)), [13.] * len(self.train_scores), color='black')
        _ = plt.yticks(np.linspace(-2, 24, 27, endpoint=True))
        _ = plt.xticks(np.linspace(0, len(self.train_scores)+1, len(self.train_scores)+2, endpoint=True))
        plt.grid()



if __name__ == '__main__':
    from unityagents import UnityEnvironment
    agent = Agent(37, 30, 30, 4, device)
    env = UnityEnvironment(file_name="/data/Banana_Linux_NoVis/Banana.x86_64")