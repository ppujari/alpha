from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults

class LoadFactOperator(BaseOperator):
    ui_color = '#F98866'
    load_fact_sql_template = """
    DROP TABLE IF EXISTS {destination_table};
    CREATE TABLE {destination_table} AS
    {insert_statement}
    ;
    """

    @apply_defaults
    def __init__(self,
                 redshift_conn_id="",
                 insert_statement="",
                 destination_table="",
                 *args, **kwargs):

        super(LoadFactOperator, self).__init__(*args, **kwargs)
        self.redshift_conn_id = redshift_conn_id
        self.insert_statement = insert_statement
        self.destination_table = destination_table

    def execute(self, context):
        self.log.info('Loading data to songplays fact table')
        redshift = PostgresHook(postgres_conn_id=self.redshift_conn_id)
        facts_sql = LoadFactOperator.load_fact_sql_template.format(
            destination_table=self.destination_table,
            insert_statement=self.insert_statement
        )
        redshift.run(facts_sql)
