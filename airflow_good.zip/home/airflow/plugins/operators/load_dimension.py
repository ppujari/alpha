from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults

class LoadDimensionOperator(BaseOperator):
    ui_color = '#80BD9E'
    drop_insert_dimension_sql_template = """
    DROP TABLE IF EXISTS {destination_table};
    CREATE TABLE {destination_table} AS
    {insert_statement}
    ;
    """
    insert_dimension_sql_template = """
    INSERT INTO {destination_table}
    {insert_statement}
    ;
    """

    @apply_defaults
    def __init__(self,
                 redshift_conn_id="",
                 insert_statement="",
                 destination_table="",
                 drop_insert=True,
                 *args, **kwargs):

        super(LoadDimensionOperator, self).__init__(*args, **kwargs)
        self.redshift_conn_id = redshift_conn_id
        self.insert_statement = insert_statement
        self.destination_table = destination_table
        self.drop_insert = drop_insert

    def execute(self, context):
        self.log.info('Loading data to dimension table')
        redshift = PostgresHook(postgres_conn_id=self.redshift_conn_id)

        if self.drop_insert:
            facts_sql = LoadDimensionOperator.drop_insert_dimension_sql_template.format(
                destination_table=self.destination_table,
                insert_statement=self.insert_statement
            )
        else:
            facts_sql = LoadDimensionOperator.insert_dimension_sql_template.format(
                destination_table=self.destination_table,
                insert_statement=self.insert_statement
            )

        redshift.run(facts_sql)
