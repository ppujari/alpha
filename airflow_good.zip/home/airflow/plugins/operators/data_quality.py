import logging
from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults

class DataQualityOperator(BaseOperator):
    ui_color = '#89DA59'
    test_sql_template = """
    {test_statement}
    ;
    """

    @apply_defaults
    def __init__(self,
                 redshift_conn_id="",
                 test_statement="",
                 expected_result="",
                 table="",
                 *args, **kwargs):

        super(DataQualityOperator, self).__init__(*args, **kwargs)
        self.redshift_conn_id = redshift_conn_id
        self.test_statement = test_statement
        self.expected_result = expected_result
        self.table = table

    def execute(self, context):
        self.log.info('Running quality check')
        redshift_hook = PostgresHook(self.redshift_conn_id)

        test_sql = DataQualityOperator.test_sql_template.format(test_statement=self.test_statement)
        records = redshift_hook.get_records(f"{test_sql}")

        if len(records) < 1 or len(records[0]) < 1:
            raise ValueError(f"Data quality check failed. {self.table} returned no results")
        num_records = records[0][0]
        if num_records != self.expected_result:
            raise ValueError(f"Data quality check failed. {self.table} does not contain 104 rows as expected")
        logging.info(f"Data quality on table {self.table} check done with {records[0][0]} records found")
